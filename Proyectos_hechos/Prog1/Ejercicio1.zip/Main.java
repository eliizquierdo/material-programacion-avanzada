public class Main {
  public static void main(String[] args) {
    double resul=inverso(0);
    System.out.println("El cuadrado es: "+resul);
  }
  
 public static int cuadrado(int nro1 ){
   
   return nro1*nro1;
   
 }
 
 public static int triple(int nro2){
   
   return nro2*3;
 }
 
 public static int mitad(int nro3){
   
   return nro3/2;
 }
 
 public static int cubo(int nro4){
   
   return nro4*nro4*nro4;
 }
 
  public static double inverso(double nro5){
   
   return (1/nro5);
 }
 
 
}

