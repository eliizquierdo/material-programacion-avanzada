Escribir un programa que pida por teclado tres notas de un alumnos en el curso de métodos discretos, calcule el promedio de las notas e imprima algunos de estos mensajes:

-Si el promedio es >=8 mostrar "Promocionado"

-Si el promedio es >=4 mostrar "Examen reglamentado"

-Si el promedio es <4 mostrar "Examen libre"