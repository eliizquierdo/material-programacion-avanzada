import java.util.Scanner;

class Main {
 public static void main(String[] args) {
		Scanner entrada=new Scanner(System.in);
		
		System.out.println("Ingrese un valor: ");
		int nro=entrada.nextInt();
		int resul=sumarEnteros(nro);
		
		System.out.println("El resultado de sumar los enteros es: "+resul);
		
}

//Escribe aquí el codigo de la función sumarEnteros
public static int sumarEnteros(int n){
  if (n==1)
    return(1);
  else
    return (n+sumarEnteros(n-1));
}

//Escribe aquí la función misterio

}