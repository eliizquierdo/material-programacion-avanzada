A) Definir por recursión la función **sumarEnteros: Int**    →  **Int** tal que (sumarEnteros n) es la suma de los naturales de n a 1, es decir: 1 + 2 +3 +4 +...+ n

Por ej: sumarEnteros(4) = 10  

B) Escribir la función recursiva

**misterio: Int**    →  **Int** teniendo en cuenta que:

`misterio(n)=3*misterio(n-1)`

`misterio(2)=4`

Por ej: misterio(6) = 324

C) Escribir la función recursiva

**tio: Int**    →  **Int** teniendo en cuenta que:

`tio(n)=9+tio(n-1)`

`tio(0)=2`

Por ej: tio(4) = 38